package com.beamotivator.beam.models;

public class ModelGroupNames {
    String groupTitle;

    public ModelGroupNames(){

    }

    public ModelGroupNames(String groupTitle) {
        this.groupTitle = groupTitle;

    }

    public String getGroupTitle() {
        return groupTitle;
    }

    public void setGroupTitle(String groupTitle) {
        this.groupTitle = groupTitle;
    }
}
